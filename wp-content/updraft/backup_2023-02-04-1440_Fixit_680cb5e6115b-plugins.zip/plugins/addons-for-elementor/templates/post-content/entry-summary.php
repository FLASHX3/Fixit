<?php
?>

<div class="lae-post-summary">

    <?php echo get_the_excerpt(); ?>

</div>